<?php
// Text
$_['heading_title'] = 'BraxTI - Notification';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success: You have modified BraxTI Notification module!';
$_['text_edit']          = 'Edit module';

// Entry
$_['entry_status']       = 'Status';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify BraxTI Notification!';