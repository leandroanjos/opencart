<?php
// Text
$_['heading_title'] = 'BraxTI - Notificações';

// Text
$_['text_extension']     = 'Extensões';
$_['text_success']       = 'Successo: Você alterou o modulo de Notificações!';
$_['text_edit']          = 'Alterar Módulo';

// Entry
$_['entry_status']       = 'Situação';

// Error
$_['error_permission']   = 'Aviso: Você não tem permissão para alterar o módulo de Notificações!';