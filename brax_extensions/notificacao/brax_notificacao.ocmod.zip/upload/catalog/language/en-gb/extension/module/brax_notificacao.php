<?php
// Text
$_['text_subject']        = '%s - Sua conta foi liberada!';
$_['text_welcome']        = '';
$_['text_login']          = 'Sua conta foi liberada em nossa loja! Para ingressar na sua conta, utilize seu e-mail e senha 123456 acessando o link abaixo ou diretamente pelo site.';
$_['text_redefine']       = '***IMPORTANTE: Redefina sua senha após o primeiro acesso.';
$_['text_service']        = 'Em caso de dúvidas, favor entrar em contato com nosso televendas.';
$_['text_thanks']         = 'Atenciosamente,';

$_['button_login']           = 'Login';
