<?php
// Text
$_['text_botao_download'] = 'Downloads';