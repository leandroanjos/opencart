<?php
// Text
$_['heading_title'] = 'BraxTI - Botão de Download';

// Text
$_['text_extension']     = 'Extensões';
$_['text_success']       = 'Successo: Você alterou o modulo Botão de Download!';
$_['text_edit']          = 'Alterar Módulo';

// Entry
$_['entry_status']       = 'Situação';
$_['entry_information_code']       = 'Código da Informação';

// Error
$_['error_permission']   = 'Aviso: Você não tem permissão para alterar o módulo Botão de Download!';