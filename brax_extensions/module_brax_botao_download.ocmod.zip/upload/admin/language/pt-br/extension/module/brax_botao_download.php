<?php
// Text
$_['heading_title'] = 'BraxTI - Botão de Download';

// Text
$_['text_extension']     = 'Extensões';
$_['text_success']       = 'Successo: Você alterou o modulo Botão de Download!';
$_['text_edit']          = 'Alterar Módulo';

// Entry
$_['entry_status']       = 'Situação';
$_['entry_information_code_0']       = 'Código da Informação (Loja 01)';
$_['entry_information_code_1']       = 'Código da Informação (Loja 02)';
$_['entry_information_code_2']       = 'Código da Informação (Loja 03)';
$_['entry_information_code_3']       = 'Código da Informação (Loja 04)';
$_['entry_information_code_4']       = 'Código da Informação (Loja 05)';

// Error
$_['error_permission']   = 'Aviso: Você não tem permissão para alterar o módulo Botão de Download!';