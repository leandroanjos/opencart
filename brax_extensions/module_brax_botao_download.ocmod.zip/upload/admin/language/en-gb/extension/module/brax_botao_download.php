<?php
// Text
$_['heading_title'] = 'BraxTI - Download Button';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success: You have modified Download Button module!';
$_['text_edit']          = 'Edit module';

// Entry
$_['entry_status']       = 'Status';
$_['entry_information_code']       = 'Information Code';
$_['entry_information_code_0']       = 'Information Code (Store 01)';
$_['entry_information_code_1']       = 'Information Code (Store 02)';
$_['entry_information_code_2']       = 'Information Code (Store 03)';
$_['entry_information_code_3']       = 'Information Code (Store 04)';
$_['entry_information_code_4']       = 'Information Code (Store 05)';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Download Button!';