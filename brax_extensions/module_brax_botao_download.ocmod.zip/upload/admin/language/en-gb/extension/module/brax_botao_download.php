<?php
// Text
$_['heading_title'] = 'BraxTI - Download Button';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success: You have modified Download Button module!';
$_['text_edit']          = 'Edit module';

// Entry
$_['entry_status']       = 'Status';
$_['entry_information_code']       = 'Information Code';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Download Button!';