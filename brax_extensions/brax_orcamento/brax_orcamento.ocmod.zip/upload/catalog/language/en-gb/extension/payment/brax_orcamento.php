<?php
// Text
$_['text_title'] = 'Solicitação de Compra';