<?php
// Heading
$_['heading_title']      = 'Solicitação Brax ERP';

// Text
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Success: You have modified Solicitação Brax ERP module!';
$_['text_edit']          = 'Edit Solicitação Brax ERP';

// Entry
$_['entry_order_status'] = 'Order Status';
$_['entry_status']       = 'Status';
$_['entry_sort_order']   = 'Sort Order';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Solicitação Brax ERP!';