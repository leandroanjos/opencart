<?php
// Text
$_['heading_title'] = 'BraxTI - Multiplicador de Quantidade';

// Text
$_['text_extension']     = 'Extensões';
$_['text_success']       = 'Successo: Você alterou o modulo Multiplicador de Quantidade!';
$_['text_edit']          = 'Alterar Módulo';

// Entry
$_['entry_status']       = 'Situação';

// Error
$_['error_permission']   = 'Aviso: Você não tem permissão para alterar o módulo Multiplicador de Quantidade!';