<?php
// Text
$_['text_payment_term'] = 'Condição de Pagto';