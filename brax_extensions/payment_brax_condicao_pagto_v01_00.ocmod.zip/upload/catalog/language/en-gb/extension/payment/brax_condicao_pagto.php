<?php
// Text
$_['text_payment_term'] = 'Payment Term';