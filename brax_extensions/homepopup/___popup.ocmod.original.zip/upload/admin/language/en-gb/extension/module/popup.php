<?php
// Heading
$_['heading_title']             = 'COVID19 Strip';
$_['heading_title_main']        = 'COVID19 Strip Module';
$_['heading_title_module']      = 'COVID19 Strip Module';
$_['general_text_title']      = 'Text: ';
$_['general_text_discount_text']      = 'Discount Information Text: ';
$_['general_text_discount_limit_text']      = 'Discount Limit Text: ';
$_['general_text_button']      = 'Button Text: ';
$_['look_text_expires']      = 'Expire Cookies(in Days): ';
$_['general_text_popup_background']      = 'Popup Border Color: ';
$_['text_covid_background_image']      = 'Background Image: ';
$_['general_text_border_color']      = 'Button Border Color: ';
$_['general_text_discount_info_color']      = 'Discount Information Text Color: ';
$_['general_text_discount_limit_color']      = 'Discount Limit Text Color: ';
$_['general_text_button_text']      = 'Button Text Color: ';
$_['general_text_button_background']      = 'Button Background Color: ';
$_['general_text_title_text']      = 'Popup Title Color: ';
$_['discount_text_type']      = 'Discount Type: ';
$_['discount_text_value']      = 'Discount Value: ';
$_['discount_text_period']      = 'Discount Period: ';
$_['general_text_banner_background']      = 'Banner Background Color: ';
$_['general_text_banner_text']      = 'Banner Text Color: ';
$_['general_text_button_background']      = 'Button Background Color: ';
$_['general_text_button_text']      = 'Button Text Color: ';
$_['text_general_enable_tooltip']      = 'Enable/Disable module as per requirements: ';
$_['text_general_type_tooltip']      = 'Select Display Type: ';
$_['text_general_title_tooltip']      = 'Main text to be display on Popup.';
$_['text_general_button_background_tooltip']      = 'Background Color for Button.';
$_['text_general_button_text_tooltip']      = 'Text color for Button.';
$_['text_general_discount_text_tooltip']      = 'Information about Discount to be displayed on popup.';
$_['text_general_discount_limit_text_tooltip']      = 'Information about Discount expiry date.';
$_['text_general_text_button_tooltip']      = 'Text for Button.';
$_['text_look_expires_tooltip']      = 'No. of days after cookie expires';
$_['text_general_popup_background_tooltip']      = 'Border Color of Popup.';
$_['text_general_title_text_tooltip']      = 'Text color on Popup.';
$_['text_general_border_color_tooltip']      = 'Border Color of Button.';
$_['text_general_discount_info_color_tooltip']      = 'Text Color of Discount Information.';
$_['text_general_discount_limit_color_tooltip']      = 'Text Color of Discount Limit.';
$_['text_general_button_text_tooltip']      = 'Text Color of Button.';
$_['text_general_button_background_tooltip']      = 'Background Color of Button.';
$_['text_type_tooltip']      = 'Choose type of discount.';
$_['text_discount_period_tooltip']      = 'Enter Discount Period after which coupon will expire.';


$_['tab_cookie']      = 'Cookie Settings';
// Text
$_['text_edit']         = 'Strip Module';
$_['text_module']      = 'Modules';
$_['text_success']        = 'Success: You have modified module Strip!';

//text general tab
$_['text_general_enable']     = 'Enable/Disable :';
$_['text_general_type']     = 'Display Type :';
$_['text_discount_info']     = 'Discount Information';
$_['text_discount_text']     = 'Discount Limit Text';
$_['text_discount_info_color'] = 'Discount Info Color:';

//text discount tab
$_['text_percentage'] = 'Once Every Day';
$_['text_fixed_amount'] = 'Once Every Hour';
$_['text_per_week'] = 'Once Every Week';


// Tab
$_['tab_general']	= 'General Settings';
$_['tab_look']          = 'Look and Feel Settings';
$_['tab_discount']	= 'Discount Settings';
$_['tab_statistics']	= 'Statistics';
$_['tab_statistics_text']	= 'Statistics (Top 20 Customers)';
$_['popup_id']	= 'Id';
$_['text_email']	= 'Email Id';
$_['text_device']	= 'Device';
$_['text_ip']	= 'IP Address';
$_['text_date']	= 'Date Added';
$_['button_export']	= 'Export All';
$_['text_coupon']	= 'Coupon';

//look and feel tab tooltip

//discount tab tooltip
$_['discount_period_tooltip']='Discount Validity after coupon has been generated.';
$_['discount_cart_tooltip']='Minimum Cart Amount on which offer is applicable.';


// Error
$_['error_permission']	= 'Warning: You do not have permission to modify Exit Popup Module!';
$_['error_google_reCaptcha_time']	= 'Required Field';
$_['error_google_reCaptcha_time_digit']	= 'Only digits are allowed';
$_['error_google_reCaptcha_time_negative']	= 'Only Positive values are allowed';
$_['error_google_reCaptcha_pages']	= 'Please select at least 1 page';
?>